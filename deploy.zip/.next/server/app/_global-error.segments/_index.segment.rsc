1:"$Sreact.fragment"
2:I[93510,["/_next/static/chunks/444a836de069db2b.js"],"default"]
3:I[7841,["/_next/static/chunks/444a836de069db2b.js"],"default"]
0:{"buildId":"2s31FkyVuWLXp642R_B1V","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
